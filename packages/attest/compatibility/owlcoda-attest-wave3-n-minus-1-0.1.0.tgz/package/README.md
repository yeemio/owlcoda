# `@owlcoda/attest`

`@owlcoda/attest` is OwlCoda RunKit's unsigned, read-only verification plane.
It verifies Quick Receipt V1 artifacts, Formal public verification bundles, and
local `OwlCodaAttestationRefV1` references without importing the private
mutation Core.

The package is a Wave 2 distribution candidate. It is intentionally marked
private until naming clearance and release authorization exist.

## CLI

```text
owlcoda-attest attest <receipt-or-bundle.json> [--workspace <path>] [--json]
owlcoda-attest resolve <attestation-ref.json> --store <path> [--store <path>...] [--workspace <path>] [--json]
```

Resolution searches only the explicitly supplied local stores. Both commands
perform zero network requests and always report `authorizationGranted: false`.

## API

```js
import {
  attestFile,
  createAttestationRef,
  parseAttestationRef,
  resolveAttestationRef,
  verifyBundle,
} from "@owlcoda/attest";
```

Quick `GO` means the captured command, receipt material, current bound source,
runtime context, and supported Core identity verify under the unsigned Quick
policy. It does not mean Formal acceptance, independent review, Git authority,
release authority, or business-action authority.
