import { lstatSync, realpathSync, statSync } from "node:fs";
import path from "node:path";

import {
  hasExactKeys,
  isPlainJsonObject,
  isSha256Ref,
  decodeUtf8Strict,
  parseJsonStrict,
  readFileBytesBounded,
  resolveRegularFilePath,
  sha256Bytes,
  sha256Canonical,
} from "./formal.mjs";
import { captureWorkspaceSnapshot } from "./workspace-snapshot.mjs";

export const SUPPORTED_QUICK_CORE_IDENTITIES = Object.freeze([
  {
    contractVersion: "0.2",
    coreVersion: "0.12.0",
    coreManifestSha256: "sha256:c415b10cb00d2a7891744b7257774fa501ddf40f8ec2f290356505a17fefb40f",
  },
  {
    contractVersion: "0.2",
    coreVersion: "0.12.0",
    coreManifestSha256: "sha256:be4b079fb0bc29e71858af03a1e579f864d4414c815ac612c3b514d8d663d07b",
  },
  {
    contractVersion: "0.2",
    coreVersion: "0.13.0",
    coreManifestSha256: "sha256:0e3233a417365afb4e2ce22db5260608a9c697a819cd5c02897276d6454dde1f",
  },
  {
    contractVersion: "0.2",
    coreVersion: "0.13.0",
    coreManifestSha256: "sha256:037c012751b32abbbb48ce8a8d2cd8faa4fc2c38d6797db391205477e667065f",
  },
]);

const RECEIPT_REQUIRED_KEYS = [
  "schemaVersion",
  "receiptId",
  "assurance",
  "authorizationGranted",
  "coreIdentity",
  "workspaceBefore",
  "exactCommand",
  "verificationContext",
  "startedAt",
  "finishedAt",
  "exitResult",
  "outputArtifacts",
  "workspaceAfter",
  "mutationDecision",
  "issueCodes",
];
const SNAPSHOT_REQUIRED_KEYS = [
  "schemaVersion",
  "repositoryIdentity",
  "headCommit",
  "trackedTreeIdentity",
  "submodules",
  "dirtyOverlay",
  "dependencyLockfiles",
  "excludedRoots",
  "ignoredPathsBound",
  "policyVersion",
  "sourceFingerprint",
];
const KNOWN_RECEIPT_ISSUES = new Set([
  "quick_ignored_artifact_unbound",
  "source_mutated_during_verification",
]);

function validDateTime(value) {
  return typeof value === "string"
    && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(value)
    && Number.isFinite(Date.parse(value));
}

function validCoreIdentity(value) {
  return hasExactKeys(value, ["contractVersion", "coreVersion", "coreManifestSha256"])
    && typeof value.contractVersion === "string"
    && value.contractVersion.length > 0
    && typeof value.coreVersion === "string"
    && value.coreVersion.length > 0
    && isSha256Ref(value.coreManifestSha256);
}

function validSnapshot(value) {
  if (!hasExactKeys(value, SNAPSHOT_REQUIRED_KEYS)) return false;
  if (
    value.schemaVersion !== "OwlCodaWorkspaceSnapshotV1"
    || typeof value.repositoryIdentity !== "string"
    || value.repositoryIdentity.length === 0
    || !(value.headCommit === null || /^[0-9a-f]{40}(?:[0-9a-f]{24})?$/.test(value.headCommit))
    || !isSha256Ref(value.trackedTreeIdentity)
    || value.ignoredPathsBound !== false
    || value.policyVersion !== "workspace-snapshot-v1"
    || !isSha256Ref(value.sourceFingerprint)
    || !Array.isArray(value.submodules)
    || !Array.isArray(value.dirtyOverlay)
    || !Array.isArray(value.dependencyLockfiles)
    || !Array.isArray(value.excludedRoots)
    || !value.excludedRoots.includes(".owlcoda/runkit")
  ) {
    return false;
  }
  if (!value.submodules.every((entry) =>
    hasExactKeys(entry, ["path", "commit"])
    && typeof entry.path === "string"
    && /^[0-9a-f]{40}(?:[0-9a-f]{24})?$/.test(entry.commit))) {
    return false;
  }
  if (!value.dirtyOverlay.every((entry) =>
    hasExactKeys(entry, ["path", "state", "sha256"])
    && typeof entry.path === "string"
    && ["modified", "untracked", "deleted"].includes(entry.state)
    && (entry.sha256 === null || isSha256Ref(entry.sha256)))) {
    return false;
  }
  if (!value.dependencyLockfiles.every((entry) =>
    hasExactKeys(entry, ["path", "sha256"])
    && typeof entry.path === "string"
    && isSha256Ref(entry.sha256))) {
    return false;
  }
  return true;
}

function snapshotFingerprintValid(value) {
  const { sourceFingerprint, ...payload } = value;
  return sha256Canonical(payload) === sourceFingerprint;
}

function validOutputArtifact(value) {
  return hasExactKeys(value, ["path", "sha256", "sizeBytes"])
    && typeof value.path === "string"
    && value.path.length > 0
    && isSha256Ref(value.sha256)
    && Number.isInteger(value.sizeBytes)
    && value.sizeBytes >= 0;
}

export function validQuickReceiptShape(receipt) {
  if (!hasExactKeys(receipt, RECEIPT_REQUIRED_KEYS, ["signatureRef"])) return false;
  if (
    receipt.schemaVersion !== "OwlCodaQuickVerificationReceiptV1"
    || typeof receipt.receiptId !== "string"
    || receipt.receiptId.length === 0
    || receipt.assurance !== "captured_verification"
    || receipt.authorizationGranted !== false
    || !validCoreIdentity(receipt.coreIdentity)
    || !validSnapshot(receipt.workspaceBefore)
    || !validSnapshot(receipt.workspaceAfter)
    || !hasExactKeys(receipt.exactCommand, ["executable", "argv", "cwd"])
    || typeof receipt.exactCommand.executable !== "string"
    || receipt.exactCommand.executable.length === 0
    || !Array.isArray(receipt.exactCommand.argv)
    || !receipt.exactCommand.argv.every((entry) => typeof entry === "string")
    || typeof receipt.exactCommand.cwd !== "string"
    || receipt.exactCommand.cwd.length === 0
    || !hasExactKeys(receipt.verificationContext, ["platform", "architecture", "runtime"])
    || !Object.values(receipt.verificationContext).every((entry) => typeof entry === "string" && entry.length > 0)
    || !validDateTime(receipt.startedAt)
    || !validDateTime(receipt.finishedAt)
    || Date.parse(receipt.finishedAt) < Date.parse(receipt.startedAt)
    || !hasExactKeys(receipt.exitResult, ["exitCode", "signal"])
    || !(receipt.exitResult.exitCode === null || Number.isInteger(receipt.exitResult.exitCode))
    || !(receipt.exitResult.signal === null || typeof receipt.exitResult.signal === "string")
    || !hasExactKeys(receipt.outputArtifacts, ["stdout", "stderr"])
    || !validOutputArtifact(receipt.outputArtifacts.stdout)
    || !validOutputArtifact(receipt.outputArtifacts.stderr)
    || !["source_unchanged", "invalidated_by_command_source_mutation"].includes(receipt.mutationDecision)
    || !Array.isArray(receipt.issueCodes)
    || new Set(receipt.issueCodes).size !== receipt.issueCodes.length
    || !receipt.issueCodes.every((entry) => typeof entry === "string" && KNOWN_RECEIPT_ISSUES.has(entry))
  ) {
    return false;
  }
  if (receipt.signatureRef !== undefined) {
    if (!hasExactKeys(receipt.signatureRef, ["path", "sha256"])
      || typeof receipt.signatureRef.path !== "string"
      || !isSha256Ref(receipt.signatureRef.sha256)) {
      return false;
    }
  }
  return true;
}

function resolveBoundMaterial(root, relativePath) {
  if (path.isAbsolute(relativePath) || relativePath.includes("\0")) {
    throw new Error("material path must be workspace-relative");
  }
  const segments = relativePath.split(/[\\/]/);
  if (segments.some((segment) => segment === "" || segment === "." || segment === "..")) {
    throw new Error("material path contains unsafe segments");
  }
  let current = root;
  for (const segment of segments) {
    current = path.join(current, segment);
    const stat = lstatSync(current);
    if (stat.isSymbolicLink()) throw new Error("material path traverses a symlink");
  }
  const resolved = realpathSync(current);
  const remainder = path.relative(root, resolved);
  if (remainder === "" || remainder === ".." || remainder.startsWith(`..${path.sep}`) || path.isAbsolute(remainder)) {
    throw new Error("material path escapes the workspace");
  }
  if (!statSync(resolved).isFile()) throw new Error("material must be a regular file");
  return resolved;
}

function check(status, issueCode) {
  return issueCode === undefined ? { status } : { status, issueCode };
}

function resultTemplate({ receipt, receiptPath, receiptSha256, decision, issues, checks, materials }) {
  return {
    schemaVersion: "OwlCodaAttestationResultV1",
    decision,
    subjectRef: {
      schemaVersion: "OwlCodaAttestationRefV1",
      receiptId: receipt.receiptId,
      receiptSha256,
      coreIdentity: {
        contractVersion: receipt.coreIdentity.contractVersion,
        coreManifestSha256: receipt.coreIdentity.coreManifestSha256,
      },
    },
    verifiedAt: new Date().toISOString(),
    policy: {
      id: "owlcoda-quick-minimum",
      version: "1.0.0",
    },
    checks,
    authorizationBoundary: {
      authorizationGranted: false,
      statement: "attestation_never_grants_repository_or_business_authority",
    },
    issueCodes: [...new Set(issues)].sort(),
    verifiedMaterials: [
      { path: receiptPath, sha256: receiptSha256 },
      ...materials,
    ],
  };
}

export function attestQuickReceiptDetailsFromBytes({
  receiptPath,
  receiptBytes,
  workspaceRoot,
}) {
  const absoluteReceiptPath = resolveRegularFilePath(receiptPath);
  let receipt;
  try {
    receipt = parseJsonStrict(decodeUtf8Strict(receiptBytes));
  } catch (error) {
    if (error?.code === "DUPLICATE_OBJECT_KEY") {
      error.code = "receipt_duplicate_key";
    }
    throw error;
  }
  if (!isPlainJsonObject(receipt) || !validQuickReceiptShape(receipt)) {
    const error = new Error("Quick receipt does not satisfy the strict Wave 1 shape");
    error.code = "receipt_schema_invalid";
    throw error;
  }

  const issues = [...receipt.issueCodes, "signature_absent", "anchor_absent"];
  const materials = [];
  let materialMissing = false;
  let materialMismatch = false;
  const receiptWorkspaceRoot = realpathSync(receipt.exactCommand.cwd);
  for (const artifact of [receipt.outputArtifacts.stdout, receipt.outputArtifacts.stderr]) {
    try {
      const materialPath = resolveBoundMaterial(receiptWorkspaceRoot, artifact.path);
      const { bytes } = readFileBytesBounded(materialPath);
      const actualSha256 = sha256Bytes(bytes);
      materials.push({ path: materialPath, sha256: actualSha256 });
      if (actualSha256 !== artifact.sha256 || bytes.byteLength !== artifact.sizeBytes) {
        materialMismatch = true;
      }
    } catch (error) {
      if (error && typeof error === "object" && error.code === "ENOENT") {
        materialMissing = true;
      } else {
        materialMismatch = true;
      }
    }
  }
  if (materialMissing) issues.push("attestation_material_missing");
  if (materialMismatch) issues.push("receipt_material_hash_mismatch");

  const coreValid = SUPPORTED_QUICK_CORE_IDENTITIES.some((core) =>
    receipt.coreIdentity.contractVersion === core.contractVersion
    && receipt.coreIdentity.coreVersion === core.coreVersion
    && receipt.coreIdentity.coreManifestSha256 === core.coreManifestSha256);
  if (!coreValid) issues.push("core_identity_mismatch");
  const contextValid = receipt.verificationContext.platform === process.platform
    && receipt.verificationContext.architecture === process.arch
    && receipt.verificationContext.runtime === process.version;
  if (!contextValid) issues.push("verification_context_mismatch");

  const snapshotBindingsValid = snapshotFingerprintValid(receipt.workspaceBefore)
    && snapshotFingerprintValid(receipt.workspaceAfter);
  const sourceUnchanged = receipt.workspaceBefore.sourceFingerprint
    === receipt.workspaceAfter.sourceFingerprint;
  const receiptSourceValid = receipt.mutationDecision === "source_unchanged"
    ? snapshotBindingsValid && sourceUnchanged && !receipt.issueCodes.includes("source_mutated_during_verification")
    : snapshotBindingsValid && !sourceUnchanged && receipt.issueCodes.includes("source_mutated_during_verification");
  const selectedWorkspaceRoot = workspaceRoot === undefined
    ? undefined
    : realpathSync(workspaceRoot);
  const commandWorkspaceMatches = selectedWorkspaceRoot === undefined
    || selectedWorkspaceRoot === receiptWorkspaceRoot;
  const currentSourceValid = selectedWorkspaceRoot === undefined
    || commandWorkspaceMatches
      && captureWorkspaceSnapshot(selectedWorkspaceRoot).sourceFingerprint
        === receipt.workspaceAfter.sourceFingerprint;
  const sourceValid = receiptSourceValid && currentSourceValid;
  if (!sourceValid || receipt.mutationDecision !== "source_unchanged") {
    issues.push("receipt_source_mismatch");
  }
  const commandPassed = receipt.exitResult.exitCode === 0 && receipt.exitResult.signal === null;
  if (!commandPassed) issues.push("verification_command_failed");
  const deterministicFailure = !coreValid
    || !contextValid
    || materialMismatch
    || !sourceValid
    || receipt.mutationDecision !== "source_unchanged"
    || !commandPassed;
  const decision = deterministicFailure
    ? "NO_GO"
    : materialMissing
      ? "INDETERMINATE"
      : "GO";
  const receiptSha256 = sha256Bytes(receiptBytes);

  const attestation = resultTemplate({
    receipt,
    receiptPath: absoluteReceiptPath,
    receiptSha256,
    decision,
    issues,
    materials,
    checks: {
      schema: check("passed"),
      canonicalization: check("passed"),
      lineage: check("passed"),
      source: sourceValid && receipt.mutationDecision === "source_unchanged"
        ? check("passed")
        : check("failed", "receipt_source_mismatch"),
      context: !coreValid
        ? check("failed", "core_identity_mismatch")
        : contextValid
          ? check("passed")
          : check("failed", "verification_context_mismatch"),
      signature: check("not_checked", "signature_absent"),
      key: check("not_checked", "signature_absent"),
      anchor: check("not_checked", "anchor_absent"),
    },
  });
  return {
    attestation,
    sourceFingerprint: receipt.workspaceAfter.sourceFingerprint,
    exitCode: decision === "GO"
      ? 0
      : !sourceValid || receipt.mutationDecision !== "source_unchanged"
        ? 2
        : decision === "INDETERMINATE"
          ? 3
          : 1,
  };
}

export function attestQuickReceiptDetails({ receiptPath, workspaceRoot }) {
  const { absolutePath, bytes } = readFileBytesBounded(receiptPath);
  return attestQuickReceiptDetailsFromBytes({
    receiptPath: absolutePath,
    receiptBytes: bytes,
    workspaceRoot,
  });
}

export function attestQuickReceipt(options) {
  return attestQuickReceiptDetails(options).attestation;
}
